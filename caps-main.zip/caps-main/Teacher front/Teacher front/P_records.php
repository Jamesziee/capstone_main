<!DOCTYPE html>
<html lang="en">
<html>
<head>
    <title>Student Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"/>

</head>
<body>
    <div class="sidebar">
        <div>
            <div class="logo"><img src="pic/logo.png" alt="Image" width="100" height="100"></div>
            <div class="menu-item">QR Code Scan</div>
            <div class="menu-item"><a href="S_records.php">Student Records</a></div>
            <div class="menu-item"><a href="P_records.php">Parent Records</a></div>
            <div class="menu-item"><a href="U_records.php">Pick-Up Records</a></div>
        </div>
            <div class="bottom-menu">
                <div class="menu-item"><i class="fas fa-cog"></i>Settings</div>
                <div class="menu-item"><i class="fas fa-sign-out-alt"></i>Logout</div>
            </div>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="search-bar">
                <i class="fas fa-filter"></i>
                <input type="text" placeholder="Search"/>
                <i class="fas fa-search"></i>
            </div>
            <div class="user-info">
                <img src="path_to_image" alt="User profile picture" width="40" height="40"/>
                <div class="user-name">
                    <div>STAFF</div>
                    <div>STAFF</div>
                </div>
            </div>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Contact Number</th>
                        <th>Email Address</th>
                        <th>Address</th>
                        <th>View</th>   
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><a href="#" id="viewBtn"><i class="fas fa-eye"></i></a></td>
                    </tr>
                    <form action="S_records.php" method="POST"></form>
                </tbody>
            </table>
            <div class="pagination">
                <div class="page-item">
                    <a href="#">Prev</a>
                    <a href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#">5</a>
                    <a href="#">Next</a>
                </div>
            </div>
        </div>

        <div id="myModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <div class="parent-info">
                    <img src="path_to_image" alt="Profile Picture" width="80" height="80">
                    <div class="details">
                        <p><strong>Name:</strong></p>
                        <p><strong>Contact Number:</strong></p>
                        <p><strong>Email Address:</strong></p>
                        <p><strong>Address:</strong></p>
                    </div>
                </div>
                <div class="authorized">
                    <h3>Authorized Pick-Up Persons</h3>
                    <div class="pick-up-list">
                        <div><img src="path_to_image" alt="Person 1"> </div>
                        <div><img src="path_to_image" alt="Person 2"> </div>
                        <div><img src="path_to_image" alt="Person 3"> </div>
                        <div><img src="path_to_image" alt="Person 4"> </div>
                        <a href="#">View Qr Code</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Modal script
        var modal = document.getElementById("myModal");
        var btn = document.getElementById("viewBtn");
        var span = document.getElementsByClassName("close")[0];

        // Show modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // Close modal on "x" click
        span.onclick = function() {
            modal.style.display = "none";
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>
</html>