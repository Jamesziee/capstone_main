<?php
include 'connection.php';

if (isset($_GET['parent_id'])) {
    $parentId = intval($_GET['parent_id']);

    // Fetch parent info
    $parentSql = "SELECT fullname, address FROM parent_acc WHERE id = ?";
    $stmt = $conn->prepare($parentSql);
    $stmt->bind_param("i", $parentId);
    $stmt->execute();
    $parentResult = $stmt->get_result()->fetch_assoc();

    // Fetch authorized persons
    $authSql = "SELECT fullname FROM authorized_persons WHERE parent_id = ?";
    $stmt = $conn->prepare($authSql);
    $stmt->bind_param("i", $parentId);
    $stmt->execute();
    $authResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Return JSON response
    echo json_encode([
        'success' => true,
        'parent' => $parentResult,
        'authorizedPersons' => $authResult
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid parent ID.']);
}
$conn->close();
?>
