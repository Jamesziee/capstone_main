<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get values from the form
    $id = intval($_POST['id']); // Primary Key ID
    $student_id = $_POST['student_id']; // Editable Student ID
    $name = $_POST['child_name'];
    $grade = $_POST['child_grade'];
    $section = $_POST['child_section'];
    $address = $_POST['child_address'];

    // Update query
    $stmt = $conn->prepare("UPDATE child_acc SET student_id = ?, child_name = ?, child_grade = ?, child_section = ?, child_address = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $student_id, $name, $grade, $section, $address, $id);

    if ($stmt->execute()) {
        header("Location: student.php?status=success");
    } else {
        header("Location: student.php?status=error");
    }
    $stmt->close();
    $conn->close();
} else {
    header("Location: student.php");
}
?>
